<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Family Mobile | Aksesoris</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body>
    <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="main">
        <div class="container mx-auto px-8 py-8">
            <h1 class="text-3xl font-bold text-gray-900">Aksesoris</h1>
        </div>
        <div class="w-full flex justify-center max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

            <div class="grid grid-cols-3 mt-6 w-[1200px] sm:grid-cols-2 md:grid-cols-4 gap-6">
                <?php $__currentLoopData = $aksesoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $akse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                        <img src="<?php echo e(asset('storage/' . $akse->image)); ?>" alt="<?php echo e($akse->name); ?>"
                            class="w-full h-60 object-cover">
                        <div class="p-4">
                            <h2 class="text-xl font-semibold text-gray-800 mb-2"><?php echo e($akse->name); ?></h2>
                            <p class="text-gray-600 mb-4"><?php echo e($akse->description); ?></p>
                            <p class="text-gray-600 mb-4">Rp. <?php echo e($akse->price); ?></p>
                           
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\laragon\www\Konter\resources\views/aksesoris.blade.php ENDPATH**/ ?>