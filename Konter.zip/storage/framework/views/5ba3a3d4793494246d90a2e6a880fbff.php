
   <!-- Footer -->
   <footer class="bg-gray-800 py-6 mt-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-gray-300">
            <p>&copy; 2024 Konter Famili. Semua Hak Cipta Dilindungi.</p>
        </div>
    </footer><?php /**PATH C:\laragon\www\Konter\resources\views/footer.blade.php ENDPATH**/ ?>