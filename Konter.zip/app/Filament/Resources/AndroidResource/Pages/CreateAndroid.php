<?php

namespace App\Filament\Resources\AndroidResource\Pages;

use App\Filament\Resources\AndroidResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAndroid extends CreateRecord
{
    protected static string $resource = AndroidResource::class;
}
